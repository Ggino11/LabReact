import React from 'react';
import './Card.css';
import PropTypes from 'prop-types';

function Card(props) {
  return (
  
    <div className="card">
    <h2>CARD</h2>
</div>

  );
}

export default Card;